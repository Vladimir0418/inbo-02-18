package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner num = new Scanner(System.in);
        int[] n;
        int x = 0, s = 0,g=0;
        System.out.println("Введите количество элементов массива");
        x = num.nextInt();
        g=x;
        n = new int[x];
        for (int i = 0; i < x; i++) {
            System.out.print("Введите элент масива" + i);
            System.out.println(")");
            n[i] = num.nextInt();
            s = s + n[i];
        }
        System.out.println("сумма="+s);
        s=0;
        for (int i = 0; i < x; i++) { n[i] = 0; }
        while (x > 0) {
int i;
i=0;
            System.out.print("Введите элент масива");
            System.out.println(")");
            n[i] = num.nextInt();
            s = s + n[i];
            i++;
            x = x - 1;
        }
        System.out.println("сумма="+s);
        for (int i = 0; i < x; i++) { n[i] = 0; }
        s=0;
        do {
            int i;
            i=0;
            System.out.print("Введите элент масива");
            System.out.println(")");
            n[i] = num.nextInt();
            s = s + n[i];
            i++;
            g=g-1;
        } while (g > 0);
        System.out.println("сумма="+s);
    }
}