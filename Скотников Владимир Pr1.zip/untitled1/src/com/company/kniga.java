package com.company;

public class kniga {
   String nazvanee;
    String avtor;
   int kolvostr;
   int godvep;
}
